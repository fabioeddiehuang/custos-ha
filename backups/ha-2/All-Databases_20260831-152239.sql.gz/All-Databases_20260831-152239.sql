-- Custos 逻辑备份
-- 集群     : ha-2 (id=4)
-- 源节点    : 192.168.1.213:3306
-- 生成时间  : 2026-08-31 15:22:39 (UTC+8)
-- 备份范围  : 全库
-- 包含数据  : 是
-- 数据库    : ha_local, test-ha, test177, test213, test33
--
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
SET FOREIGN_KEY_CHECKS=0;
SET UNIQUE_CHECKS=0;
SET TIME_ZONE='+08:00';
SET AUTOCOMMIT=0;

CREATE DATABASE IF NOT EXISTS `ha_local` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `ha_local`;

--
-- 表结构 ha_local.state
--
DROP TABLE IF EXISTS `state`;
CREATE TABLE `state` (
  `k` varchar(32) NOT NULL,
  `v` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 数据 ha_local.state
--
INSERT INTO `state` (`k`,`v`) VALUES
('current_master','192.168.1.213:3306');

CREATE DATABASE IF NOT EXISTS `test-ha` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `test-ha`;

CREATE DATABASE IF NOT EXISTS `test177` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `test177`;

CREATE DATABASE IF NOT EXISTS `test213` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `test213`;

CREATE DATABASE IF NOT EXISTS `test33` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `test33`;

SET FOREIGN_KEY_CHECKS=1;
SET UNIQUE_CHECKS=1;
COMMIT;
-- 备份结束
